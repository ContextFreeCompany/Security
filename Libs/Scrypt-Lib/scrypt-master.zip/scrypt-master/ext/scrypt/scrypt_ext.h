#ifndef SCRYPT_EXT_H
#define SCRYPT_EXT_H 1

#ifndef RBFFI_EXPORT
# ifdef __cplusplus
#  define RBFFI_EXPORT extern "C"
# else
#  define RBFFI_EXPORT
# endif
#endif


#endif /* SCRYPT_EXT_H */
