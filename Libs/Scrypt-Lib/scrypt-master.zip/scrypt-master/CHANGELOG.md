2.0.0
-----

Breaking Changes:

* `SCrypt::Password#hash` has been renamed to `#checksum`
  (https://github.com/pbhogan/scrypt/commit/a1a60e06ec9d863c3156ac06fda32ce82cddd759)

